# Still Cold — Shopify theme

חנות אמיתית. מעלים את התיקייה הזו ל-Shopify והאתר עולה חי על הדומיין שלך.

## איך מעלים — 6 דקות

1. פתח חשבון ב-shopify.com (יש תקופת ניסיון, ואחריה מבצע של 1$ לחודש)
2. `cd shopify && zip -r still-cold-theme.zip .`
3. בחנות: **Online Store → Themes → Add theme → Upload zip file**
4. בחר את הקובץ → **Publish**
5. **Products → Add product** — שם, מחיר 42, ותמונות
6. בעורך התבנית, בחר את המוצר בסקשן `Product Hero`

## מבנה

```
layout/theme.liquid          שלד הדף, פונטים, CSS גלובלי
templates/product.json       איזה סקשנים מרכיבים את דף המוצר
sections/                    כל הסקשנים, כולם ניתנים לעריכה מהעורך
snippets/                    רכיבים חוזרים
assets/theme.css             מערכת הצבעים והעיצוב
config/settings_schema.json  הגדרות גלובליות
```

## מה ניתן לעריכה מהעורך של Shopify

כותרות, טקסטים, מחירים, מדרגות כמות, ביקורות, שאלות ותשובות, וכל הצבעים —
בלי לגעת בקוד.

## לפני השקה

- [ ] 15-20 ביקורות עם תמונות (Judge.me — חינם)
- [ ] Guest Checkout מופעל
- [ ] משלוח מגולם במחיר
- [ ] פיקסל + CAPI + אימות דומיין
- [ ] 6 עמודי חובה
- [ ] בדיקת רכישה מקצה לקצה
